<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Opdracht;
use App\Models\Fruit;

class OpdrachtController extends Controller
{
    public function show()
    {
        $name = 'Tygo van Dorst';
        $fruits = Fruit::all();
        return view('opdracht', ['fruits' => $fruits, 'name' => $name]);
    }
}
