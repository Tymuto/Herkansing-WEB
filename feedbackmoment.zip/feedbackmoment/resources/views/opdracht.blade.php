<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <title>Opdracht</title>
</head>
<body>
    <p>Mijn naam is: {{ $name }}</p>
    <table>
        <tr>
            <th>Name</th>
            <th>Origin</th>
            <th>Stock</th>
            <th>Price</th>
        </tr>
        @foreach($fruits as $fruit)
        <tr>
            <td>{{ $fruit->name }}</td>
            <td>{{ $fruit->origin }}</td>
            <td>{{ $fruit->stock }}</td>
            <td>{{ $fruit->price }}</td>
        </tr>
        @endforeach
    </table>

</body>
</html>