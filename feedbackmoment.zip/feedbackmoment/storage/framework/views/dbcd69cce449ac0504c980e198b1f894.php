<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <title>Opdracht</title>
</head>
<body>
    <p>Mijn naam is: <?php echo e($name); ?></p>
    <table>
        <tr>
            <th>Name</th>
            <th>Origin</th>
            <th>Stock</th>
            <th>Price</th>
        </tr>
        <?php $__currentLoopData = $fruits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fruit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($fruit->name); ?></td>
            <td><?php echo e($fruit->origin); ?></td>
            <td><?php echo e($fruit->stock); ?></td>
            <td><?php echo e($fruit->price); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</body>
</html><?php /**PATH C:\Laragon\www\feedbackmoment\resources\views/opdracht.blade.php ENDPATH**/ ?>